import json
import random
import string

# interval_shifts = {
#     0.1: 9.65,
#     0.2: 20.47,
#     0.3: 17.70,
#     0.4: 14.75,
#     0.5: 9.26,
#     0.6: 7.79,
#     0.7: 7.49,
#     0.8: 8.81,
#     0.9: 3.49
# }

# interval_shifts = {
#     0.05: 4.40,
#     0.10: 17.71,
#     0.15: 20.04,
#     0.20: 20.53,
#     0.25: 18.61,
#     0.30: 16.27,
#     0.35: 2.45
#
# }
interval_shifts = {
    0.2: 10,
    0.25: 10,
    0.30: 20,
    0.35: 20,
    0.4: 20,
    0.45: 10,
    0.5: 10

}

# position_probs_start = {
#     -0.8: 0.92,
#     -0.7: 2.99,
#     -0.6: 3.49,
#     -0.5: 3.48,
#     -0.4: 4.54,
#     -0.3: 7.76,
#     -0.2: 9.45,
#     -0.1: 10.36,
#     0.0: 29.63,
#     0.1: 4.10,
#     0.2: 3.97,
#     0.3: 3.58,
#     0.4: 2.95,
#     0.5: 3.41,
#     0.6: 2.30,
#     0.7: 2.48,
#     0.8: 2.29,
#     0.9: 2.05,
#     1.0: 0.23
# }
position_probs_start = {
    -0.9: 0.24,
    -0.8: 2.06,
    -0.7: 3.59,
    -0.6: 3.50,
    -0.5: 3.54,
    -0.4: 4.59,
    -0.3: 7.19,
    -0.2: 8.61,
    -0.1: 10.09,
    0.0: 10.30,
    0.1: 5.04,
    0.2: 4.33,
    0.3: 3.58,
    0.4: 2.85,
    0.5: 3.16,
    0.6: 2.20,
    0.7: 2.09,
    0.8: 1.96,
    0.9: 1.89,
    1.0: 0.19,
}

position_probs_end = {
    -1.0: 0.11,
    -0.9: 22.85,
    -0.8: 10.10,
    -0.7: 9.32,
    -0.6: 7.47,
    -0.5: 6.75,
    -0.4: 7.69,
    -0.3: 7.23,
    -0.2: 6.99,
    -0.1: 3.04,
    -0.0: 9.95,
    0.1: 2.25,
    0.2: 1.96,
    0.3: 1.42,
    0.4: 0.68,
    0.5: 0.75,
    0.6: 0.56,
    0.7: 0.45,
    0.8: 0.36,
    0.9: 0.07
}

question_variants2 = [
    '<video>\nWhich set of frames better captures {sentence_id}: <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nFor a complete depiction of {sentence_id}, are the frames from <s-1> to <e-1> or from <s0> to <e0> more suitable?',
    '<video>\nIn portraying {sentence_id}, which frame range is more comprehensive: <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nIn which time frame is {sentence_id} better depicted: <s0> to <e0> or <s-1> to <e-1>?',
    '<video>\nDoes {sentence_id} appear more accurately in the segment <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nWhich part of the video displays {sentence_id}: from <s-1> to <e-1> or <s0> to <e0> ?',
    '<video>\nWhich frame window better encompasses the full scope of {sentence_id}: <s0> to <e0> or <s-1> to <e-1>?',
    '<video>\nIn depicting {sentence_id}, which clip is more comprehensive: <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nCan {sentence_id} be identified in the segment from <s0> to <e0> or from <s-1> to <e-1>?',
    '<video>\nIn capturing the entirety of {sentence_id}, are the frames from <s0> to <e0> more effective, or do those from <s-1> to <e-1> prevail?',
    '<video>\nWhere is {sentence_id} better illustrated: in the frames <s0> to <e0> or <s-1> to <e-1>?',
    '<video>\nDuring which frames does {sentence_id} occur: <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nWhich frame range offers a more exhaustive depiction of {sentence_id}: <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nWhich segment, <s0> to <e0> or <s-1> to <e-1>, shows {sentence_id} completely?',
    '<video>\nWhere does the complete {sentence_id} happening: in the frames from <s-1> to <e-1> or from <s0> to <e0>?'
]

# 读取文件中的所有行
with open(
        '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/8_22_filtered_data/8_22_new_short.txt',
        'r', encoding='utf-8') as file:
    lines = file.readlines()
total_duration = 0
output_data = []
cou = 0
count = 0
# 处理采样的数据
for line in lines:
    data = json.loads(line.strip())
    video_id = data['video_id']
    duration = data["duration"]
    sentence_id = data.get("sentence_id", None)  # 使用 .get 方法来安全地获取 sentence_id
    predicate_time = data["predicate_time"]
    timestamp = data["timestamp"]
    timestamp_start = timestamp[0]
    timestamp_end = timestamp[1]
    predicate_time_start = predicate_time[0]
    predicate_time_end = predicate_time[1]
    conversations = []




    total_duration += duration
# average_duration =  total_duration / count
# print(average_duration)
    if (timestamp_end - timestamp_start) / duration <= 0.3:
        # print(video_id)
        continue
    if (timestamp_end - timestamp_start) / duration >= 0.9:
        # cou+=1
        continue
    if duration >= 180:
        # print(video_id)
        # cou+=1
        continue
    if duration <= 30:
        # cou+=1
        continue
    # if predicate_time_end < timestamp_start:
    #     cou+=1


    if sentence_id:
        count += 1
        # 去除 sentence_id 前面的空格
        sentence_id = sentence_id.lstrip()
        sentence_id = sentence_id[0].lower() + sentence_id[1:]
        sentence_id = sentence_id.rstrip(string.punctuation)


        start_shift = random.choices(list(position_probs_start.keys()), list(position_probs_start.values()))[0]
        s_1 = timestamp_start + (start_shift * duration)

        max_retries = 20
        retries1 = 0
        retries2 = 0

        while (s_1 < 0 or s_1 >= duration) and retries1 < max_retries:
            start_shift = random.choices(list(position_probs_start.keys()), list(position_probs_start.values()))[0]
            s_1 = timestamp_start + (start_shift * duration)
            retries1 += 1

        if retries1 >= max_retries:
            s_1 = 0
            print(video_id)

        interval = random.choices(list(interval_shifts.keys()), list(interval_shifts.values()))[0]
        e_1 = s_1 + (interval * (timestamp_end - timestamp_start))
        while (e_1 >= duration) and retries2 < max_retries:
            interval = random.choices(list(interval_shifts.keys()), list(interval_shifts.values()))[0]
            e_1 = s_1 + (interval * (timestamp_end - timestamp_start))
            retries2 += 1

        if e_1 > duration:
            e_1 = duration

        if (e_1 - s_1) > (timestamp_end - timestamp_start):
            cou += 1
            print(video_id)
            print(s_1)
            print(e_1)
            print(timestamp_start)
            print(timestamp_end)
        # if s_1 == timestamp_start:
        #     cou+=1
        # if (timestamp_end - timestamp_start) / duration >= 0.9:
        # count-=1
        # continue
        # if (timestamp_end - timestamp_start) / duration >=0.8:
        #     cou+=1
        #     print(video_id)
        # if (e_1 - s_1) / duration <= 0.1:
        #     cou += 1
        #     print(video_id)

        # if (e_1 - s_1) / duration < 0.2:
        #     cou += 1
        #     print(video_id)
        #     continue

        question_template = random.choice(question_variants2)
        question = question_template.replace('{sentence_id}', sentence_id)

        # 添加问题到 conversations 列表
        conversations.append({"from": "human", "value": question})

        # 构造回答形式的字符串
        answer = f"{sentence_id} complete occurs from <s0> to <e0>."
        answer = answer[0].capitalize() + answer[1:]
        # 添加回答到 conversations 列表
        conversations.append({"from": "gpt", "value": answer})

        # 构造 meta 数据
        meta = {
            "duration": duration,
            "token": {
                "<s-1>": s_1,
                "<e-1>": e_1,
                "<s0>": timestamp_start,
                "<e0>": timestamp_end
            }
        }

        # 构造输出数据
        output_json = {
            "id": video_id,
            "conversations": conversations,
            "meta": meta,
            "source": "anet"
        }

        # 添加到输出数据列表
        output_data.append(output_json)
    else:
        print(f"Missing sentence_id for video_id: {video_id}")
print(cou, count, cou / count)
# 输出或存储结果
with open(
        '/home/shige4090/lxf/LXF/VTimeLLM/data/8.22_activitynet_short_distribution_law_new.json',
        'w', encoding='utf-8') as outfile:
    json.dump(output_data, outfile, indent=4, ensure_ascii=False)
