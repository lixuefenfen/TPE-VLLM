import json
import math
import random
import string

question_variants1 = [
    '<video>\nBased on the video, can you match these events to their correct time frames? ',
    '<video>\nAfter watching the video, link each event to its right segment. ',
    '<video>\nFrom the video, can you pair each event with its right time range? ',
    '<video>\nMatch the following events with the corresponding video frame based on the video content. ',
    '<video>\nCorrelate the given events with their respective video sections based on the video. ',
    '<video>\nAccording to the video you just saw, which time span goes with each event? ',
    '<video>\nPlease pair these events with their matching time ranges according to the video content. ',
    '<video>\nThinking about the video, can you line up these events with their time slots? ',
    '<video>\nAfter watching the video, connect each event to its time range. ',
    '<video>\nFrom what the video showed, can you tell which time slot matches each event? ',
    '<video>\nBased on what you saw in the video, which time span fits each event? ',
    '<video>\nFrom the video, pair these events with their matching time ranges. ',
    '<video>\nCan you match these events to their correct time frames based on what you saw in the video? ',
    '<video>\nLink each event to its right segment according to the video you just watched. ',
    '<video>\nWhich time span fits each event, considering what you saw in the video? '
]

# question2 = "Event 1: {sentences_1} Event 2: {sentences_2} Event 3: {sentences_3}. Spans 1: From <s1> to <e1>. Spans 2: From <s2> to <e2>. Spans 3: From <s3> to <e3>."
def find_span_index(spans, target, tolerance=1e-6):
    for i, (s, e) in enumerate(spans):
        if math.isclose(s, target[0], rel_tol=tolerance) and math.isclose(e, target[1], rel_tol=tolerance):
            return i
    return -1
    # 如果没有找到匹配的span，返回-1


output_data = []
def create_dialogue_data(filtered_data):


    for video_id, video_info in filtered_data.items():
        timestamps = video_info['timestamps']
        sentences = video_info['sentences']
        duration = video_info["duration"]
        processed_sentences = []
        conversations = []
        for sentence in sentences:
            # 去除 sentence_id 前面的空格
            sentence = sentence.lstrip()
            sentence = sentence[0].capitalize() + sentence[1:]
            processed_sentences.append(sentence)

        original_pairs = list(zip(processed_sentences, timestamps))

        # 打乱events和spans的顺序
        shuffled_events = processed_sentences.copy()
        random.shuffle(shuffled_events)
        shuffled_spans = timestamps.copy()
        random.shuffle(shuffled_spans)

        question_template = random.choice(question_variants1)

        # 构造问题
        question = question_template
        for i, sent in enumerate(shuffled_events, 1):
            question += f"Event {i}: {sent} "
        # question = question.rstrip()
        # 构造时间跨度

        for i, (start, end) in enumerate(shuffled_spans, 1):
            question += f"Spans {i}: From <s{i}> to <e{i}>. "


        # 构造答案
        answer = "The correct matches are: "
        for i, event in enumerate(shuffled_events, 1):
            original_span = next(span for (e, span) in original_pairs if e == event)
            span_index = find_span_index(shuffled_spans, original_span) + 1
            if span_index == 0:  # 如果没有找到匹配的span
                print(f"Warning: Could not find matching span for event {i} in video {video_id}")
                continue
            answer += f"Event {i} matches span {span_index}, "
        answer = answer.rstrip(", ")  # 移除最后的逗号和空格
        answer += "."  # 添加句号


        conversations.append({"from": "human", "value": question})
        conversations.append({"from": "gpt", "value": answer})

        meta = {
            "duration": duration,
            "token": {
            }
        }

        for i, (start, end) in enumerate(shuffled_spans, 1):
            meta["token"][f"<s{i}>"] = start
            meta["token"][f"<e{i}>"] = end

        output_json = {
            "id": video_id,
            "conversations": conversations,
            "meta": meta,
            "source": "anet"
        }
        output_data.append(output_json)
    return output_data

# 读取过滤后的数据
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/task01_event_time_match/anet_train.json', 'r') as f:
    filtered_data = json.load(f)

# 创建对话数据
dialogue_data = create_dialogue_data(filtered_data)

# 将对话数据写入新文件
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/task01_event_time_match/8.31_event_time_match_QA_new.json', 'w', encoding='utf-8') as f:
    json.dump(dialogue_data, f, ensure_ascii=False, indent=2)

print(f"Generated dialogue data for {len(dialogue_data)} videos.")