import json
import random


# 读取 JSON 文件内容
def read_json_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)


data1 = read_json_file('/home/shige4090/lxf/LXF/VTimeLLM/data/stage3_delete_VideoInstruct.json')
# 读取第一个 JSON 文件中的数据
data2 = read_json_file('/home/shige4090/lxf/LXF/VTimeLLM/data/8.31_exp04_not_delete_new_video_+_even_ratio/exp002_random_selete_2500_left.json')
data3 = read_json_file(
    '/home/shige4090/lxf/LXF/VTimeLLM/data/8.31_exp04_not_delete_new_video_+_even_ratio/exp002_random_selete_2500_long.json')
data4 = read_json_file(
    '/home/shige4090/lxf/LXF/VTimeLLM/data/8.31_exp04_not_delete_new_video_+_even_ratio/exp002_random_selete_2500_right.json')
data5 = read_json_file(
    '/home/shige4090/lxf/LXF/VTimeLLM/data/8.31_exp04_not_delete_new_video_+_even_ratio/exp002_random_selete_2500_short.json')
# 读取第二个 JSON 文件中的数据
data6 = read_json_file(
    '/home/shige4090/lxf/LXF/VTimeLLM/data/task01_event_time_match/8.31_event_time_match_QA_new.json')
data7 = read_json_file(
    '/home/shige4090/lxf/LXF/VTimeLLM/data/task02_order_for_events/8.28_order_for_events.json')
data8 = read_json_file(
    '/home/shige4090/lxf/LXF/VTimeLLM/data/task03_select_event_for_given_time/select_event_for_given_time.json')
data9 = read_json_file(
    '/home/shige4090/lxf/LXF/VTimeLLM/data/task04_select_time_for_given_event/select_time_for_given_event.json')


# 合并两个文件中的数据
merged_data = data1 + data2 + data3 + data4 + data5 +data6+data7+data8+data9

# 将合并且打乱的数据写入新的 JSON 文件
with open(
        '/home/shige4090/lxf/LXF/VTimeLLM/data/8.31_exp04_not_delete_new_video_+_even_ratio/9.1_exp04_002_l+r+s+l_2500_delete_repeat_+four+task_full_.json',
        'w', encoding='utf-8') as outfile:
    json.dump(merged_data, outfile, indent=4, ensure_ascii=False)

print("Data merged and shuffled successfully.")
