import json
import math
import random
import string

question_variants2 = [
    '<video>\nFrom the video content, do you know when {sentence} appear in? From frames <s0> to <e0> or from <s1> to <e1>?',
    '<video>\nBased on the video content, can you tell when {sentence} occurs? Is it between frames <s0> to <e0> or from <s1> to <e1>?',
    '<video>\nCan you pinpoint when {sentence} occurs based on the video content? Is it during frames from <s0> to <e0> or from <s1> to <e1>?',
    '<video>\nPlease select a segment from either <s0> to <e0> or <s1> to <e1> where {sentence} is present in the footage.',
    '<video>\nIn the context of the video where would you situate {sentence}? Is it within the frame sequence <s0> to <e0> or <s1> to <e1>?',
    '<video>\nCan you pinpoint a segment from <s0> to <e0> or <s1> to <e1> in which {sentence} is visible?',
    '<video>\nPlease indicate which range, from <s0> to <e0> or from <s1> to <e1>, shows {sentence} in the video content.',
    '<video>\nPlease determine which segment, <s0> to <e0> or <s1> to <e1>, captures {sentence} in the video.',
    "<video>\nPlease select a segment between <s0> and <e0> or between <s1> and <e1> that includes {sentence} in the video.",
    '<video>\nPlease pick a section from <s0> to <e0> or <s1> to <e1> where {sentence} can be seen in the video.',
    '<video>\nChoose an interval between <s0> to <e0> or <s1> to <e1> that {sentence} in the video content.',
    '<video>\nCan you select a segment from either <s0> to <e0> or <s1> to <e1> where {sentence} is present in the footage?',
    '<video>\nWhich timeframe captures {sentence}: is it <s0> to <e0> or <s1> to <e1>?',
    '<video>\nCould you identified which part, <s0>-<e0> or <s1>-<e1>, contains {sentence} in the video?',
    "<video>\nWhich portion of the video contains {sentence}: the <s0> to <e0> part or the <s1> to <e1> part?"
]

question_variants3 = [
    '<video>\nFrom the video content, do you know when {sentence} appear in? From frames <s0> to <e0>, from <s1> to <e1> or from <s2> to <e2>?',
    '<video>\nBased on the video content, can you tell when {sentence} occurs? Is it between frames <s0> to <e0>, from <s1> to <e1>, or from <s2> to <e2>?',
    '<video>\nCan you pinpoint when {sentence} occurs based on the video content? Is it during frames from <s0> to <e0>, from <s1> to <e1>, or from <s2> to <e2>?',
    '<video>\nPlease select a segment from either <s0> to <e0>, <s1> to <e1>, or <s2> to <e2> where {sentence} is present in the footage.',
    '<video>\nIn the context of the video where would you situate {sentence}? Is it within the frame sequence <s0> to <e0>, <s1> to <e1>, or <s2> to <e2>?',
    '<video>\nCan you pinpoint a segment from <s0> to <e0>, <s1> to <e1>, or <s2> to <e2> in which {sentence} is visible?',
    '<video>\nPlease indicate which range, from <s0> to <e0>, from <s1> to <e1>, or from <s2> to <e2>, shows {sentence} in the video content.',
    '<video>\nPlease determine which segment, <s0> to <e0>, <s1> to <e1>, or <s2> to <e2>, captures {sentence} in the video.',
    "<video>\nPlease select a segment between <s0> and <e0>, between <s1> and <e1>, or between <s2> and <e2> that includes {sentence} in the video.",
    '<video>\nPlease pick a section from <s0> to <e0>, <s1> to <e1>, or <s2> to <e2> where {sentence} can be seen in the video.',
    '<video>\nChoose an interval between <s0> to <e0>, <s1> to <e1>, or <s2> to <e2> that contains {sentence} in the video content.',
    '<video>\nCan you select a segment from either <s0> to <e0>, <s1> to <e1>, or <s2> to <e2> where {sentence} is present in the footage?',
    '<video>\nWhich timeframe captures {sentence}: is it <s0> to <e0>, <s1> to <e1>, or <s2> to <e2>?',
    '<video>\nCould you identify which part, <s0>-<e0>, <s1>-<e1>, or <s2>-<e2>, contains {sentence} in the video?',
    "<video>\nWhich portion of the video contains {sentence}: the <s0> to <e0> part, the <s1> to <e1> part, or the <s2> to <e2> part?",
]

question_variants4 = [
    '<video>\nFrom the video content, do you know when {sentence} appear in? From frames <s0> to <e0>, from <s1> to <e1>, from <s2> to <e2>, or from <s3> to <e3>?',
    '<video>\nBased on the video content, can you tell when {sentence} occurs? Is it between frames <s0> to <e0>, from <s1> to <e1>, from <s2> to <e2>, or from <s3> to <e3>?',
    '<video>\nCan you pinpoint when {sentence} occurs based on the video content? Is it during frames from <s0> to <e0>, from <s1> to <e1>, from <s2> to <e2>, or from <s3> to <e3>?',
    '<video>\nPlease select a segment from either <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3> where {sentence} is present in the footage.',
    '<video>\nIn the context of the video where would you situate {sentence}? Is it within the frame sequence <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3>?',
    '<video>\nCan you pinpoint a segment from <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3> in which {sentence} is visible?',
    '<video>\nPlease indicate which range, from <s0> to <e0>, from <s1> to <e1>, from <s2> to <e2>, or from <s3> to <e3>, shows {sentence} in the video content.',
    '<video>\nPlease determine which segment, <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3>, captures {sentence} in the video.',
    "<video>\nPlease select a segment between <s0> and <e0>, between <s1> and <e1>, between <s2> and <e2>, or between <s3> and <e3> that includes {sentence} in the video.",
    '<video>\nPlease pick a section from <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3> where {sentence} can be seen in the video.',
    '<video>\nChoose an interval between <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3> that contains {sentence} in the video content.',
    '<video>\nCan you select a segment from either <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3> where {sentence} is present in the footage?',
    '<video>\nWhich timeframe captures {sentence}: is it <s0> to <e0>, <s1> to <e1>, <s2> to <e2>, or <s3> to <e3>?',
    '<video>\nCould you identify which part, <s0>-<e0>, <s1>-<e1>, <s2>-<e2>, or <s3>-<e3>, contains {sentence} in the video?',
    "<video>\nWhich portion of the video contains {sentence}: the <s0> to <e0> part, the <s1> to <e1> part, the <s2> to <e2> part, or the <s3> to <e3> part?",
]


# question2 = "Event 1: {sentences_1} Event 2: {sentences_2} Event 3: {sentences_3}. Spans 1: From <s1> to <e1>. Spans 2: From <s2> to <e2>. Spans 3: From <s3> to <e3>."
def find_span_index(spans, target, tolerance=1e-6):
    for i, (s, e) in enumerate(spans):
        if math.isclose(s, target[0], rel_tol=tolerance) and math.isclose(e, target[1], rel_tol=tolerance):
            return i
    return -1
    # 如果没有找到匹配的span，返回-1


def create_dialogue_data(filtered_data):
    output_data = []
    for video_id, video_info in filtered_data.items():
        timestamps = video_info['timestamps']
        sentences = video_info['sentences']
        duration = video_info["duration"]
        processed_sentences = []
        conversations = []
        for sentence in sentences:
            sentence = sentence.lstrip()
            sentence = sentence[0].lower() + sentence[1:]
            sentence = sentence.rstrip(string.punctuation)
            processed_sentences.append(sentence)
            # 选择问题模板和构造问题答案
        if len(timestamps) in [2, 3, 4]:
            if len(timestamps) == 2:
                question_template = random.choice(question_variants2)
            elif len(timestamps) == 3:
                question_template = random.choice(question_variants3)
            else:  # len(timestamps) == 4
                question_template = random.choice(question_variants4)

            # 随机选择一个句子
            selected_index = random.randint(0, len(timestamps) - 1)
            selected_sentence = processed_sentences[selected_index]
            correct_timestamp = timestamps[selected_index]

            # 随机打乱时间戳
            shuffled_timestamps = timestamps.copy()
            random.shuffle(shuffled_timestamps)

            # 构造问题
            question = question_template.format(sentence=selected_sentence)

            # 构造答案
            correct_index = shuffled_timestamps.index(correct_timestamp)
            answer = f"Based on the video content, {selected_sentence} appears from frames <s{correct_index}> to <e{correct_index}>."

        else:
            raise ValueError(f"Unexpected number of timestamps: {len(timestamps)}. Expected 2, 3, or 4.")

        conversations.append({"from": "human", "value": question})
        conversations.append({"from": "gpt", "value": answer})

        meta = {
            "duration": duration,
            "token": {}
        }
        for i, (start, end) in enumerate(shuffled_timestamps):
            meta["token"][f"<s{i}>"] = start
            meta["token"][f"<e{i}>"] = end
        output_json = {
            "id": video_id,
            "conversations": conversations,
            "meta": meta,
            "source": "anet"
        }
        output_data.append(output_json)
    return output_data

# 读取过滤后的数据
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/task4_select_time_for_given_event/filter_anet_train_data.json', 'r') as f:
    filtered_data = json.load(f)

# 创建对话数据
dialogue_data = create_dialogue_data(filtered_data)

# 将对话数据写入新文件
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/task4_select_time_for_given_event/task4_select_time_for_given_event.json', 'w', encoding='utf-8') as f:
    json.dump(dialogue_data, f, ensure_ascii=False, indent=2)

print(f"Generated dialogue data for {len(dialogue_data)} videos.")