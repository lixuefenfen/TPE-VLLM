import json
import random
import string

# interval_shifts = {
#     0.1: 9.65,
#     0.2: 20.47,
#     0.3: 17.70,
#     0.4: 14.75,
#     0.5: 9.26,
#     0.6: 7.79,
#     0.7: 7.49,
#     0.8: 8.81,
#     0.9: 3.49
# }

interval_shifts = {
    3.0: 7.56,
    3.5: 14.57,
    4.0: 10.91,
    4.5: 6.67,
    5.0: 7.50,
    5.5: 4.48,
    6.0: 4.80,
    6.5: 4.48,
    7.0: 2.65,
    7.5: 2.63,
    8.0: 2.33,
    8.5: 1.59,
    9.0: 1.55,
    9.5: 1.33,
    10.0: 3.38

}

position_probs_start = {
    -1.0: 4.19,
    -0.9: 8.80,
    -0.8: 6.14,
    -0.7: 7.16,
    -0.6: 4.46,
    -0.5: 5.33,
    -0.4: 5.45,
    -0.3: 6.12,
    -0.2: 7.88,
    -0.1: 11.10,
    0.0: 23.41,
    0.1: 2.55,
    0.2: 1.54,
    0.3: 1.24,
    0.4: 0.92,
    0.5: 1.11,
    0.6: 0.94,
    0.7: 0.79,
    0.8: 0.57,
    0.9: 0.30

}

position_probs_end = {
    -0.9: 1.51,
    -0.8: 2.16,
    -0.7: 2.06,
    -0.6: 2.16,
    -0.5: 2.73,
    -0.4: 2.16,
    -0.3: 3.00,
    -0.2: 3.12,
    -0.1: 7.28,
    -0.0: 18.73,
    0.1: 9.74,
    0.2: 7.58,
    0.3: 6.24,
    0.4: 5.72,
    0.5: 5.08,
    0.6: 4.21,
    0.7: 6.19,
    0.8: 5.75,
    0.9: 3.91,
    1.0: 0.67

}

question_variants2 = [
    '<video>\nIn which segment, <s-1> to <e-1> or <s0> to <e0>, do you see {sentence_id} happening?',
    '<video>\nWhere does {sentence_id} take place: between <s0> to <e0> or <s-1> to <e-1>?',
    '<video>\nCan you spot {sentence_id} in the frames from <s-1> to <e-1> or from <s0> to <e0>?',
    '<video>\nIn which time frame is {sentence_id} better depicted: <s0> to <e0> or <s-1> to <e-1>?',
    '<video>\nDoes {sentence_id} appear more accurately in the segment <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nWhich part of the video displays {sentence_id}: from <s0> to <e0> or from <s-1> to <e-1>?',
    '<video>\nBetween <s-1> to <e-1> and <s0> to <e0>, where can you find {sentence_id}?',
    '<video>\nIs {sentence_id} shown between frames <s-1> to <e-1> or in the range <s0> to <e0>?',
    '<video>\nCan {sentence_id} be identified in the segment from <s0> to <e0> or from <s-1> to <e-1>?',
    '<video>\nWhich timeframe includes {sentence_id}: <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nWhere is {sentence_id} better illustrated: in the frames <s0> to <e0> or <s-1> to <e-1>?',
    '<video>\nDuring which frames does {sentence_id} occur: <s-1> to <e-1> or <s0> to <e0>?',
    '<video>\nIs the event {sentence_id} visible from <s-1> to <e-1> or from <s0> to <e0>?',
    '<video>\nWhich segment, <s0> to <e0> or <s-1> to <e-1>, shows {sentence_id}?',
    '<video>\nWhere is {sentence_id} happening: in the frames from <s-1> to <e-1> or from <s0> to <e0>?'
]

# 读取文件中的所有行
with open(
        '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/long_8.18.txt',
        'r', encoding='utf-8') as file:
    lines = file.readlines()

output_data = []
cou = 0
couu =0
couuu=0
count = 0
# 处理采样的数据
for line in lines:
    # count += 1
    data = json.loads(line.strip())
    video_id = data['video_id']
    duration = data["duration"]
    sentence_id = data.get("sentence_id", None)  # 使用 .get 方法来安全地获取 sentence_id
    predicate_time = data["predicate_time"]
    timestamp = data["timestamp"]
    timestamp_start = timestamp[0]
    timestamp_end = timestamp[1]
    conversations = []
    s_1, e_1 = 0, 0

    if (timestamp_end - timestamp_start) / duration <= 0.02 :
        # cou += 1
        # print(video_id)
        continue
    if sentence_id:
        count+=1
        # 去除 sentence_id 前面的空格
        sentence_id = sentence_id.lstrip()
        sentence_id = sentence_id[0].lower() + sentence_id[1:]
        sentence_id = sentence_id.rstrip(string.punctuation)
        predicate_time_start = predicate_time[0]
        predicate_time_end = predicate_time[1]
        # timestamp_start = timestamp[0]
        # timestamp_end = timestamp[1]

        while (e_1 - s_1) < (timestamp_end - timestamp_start) or (s_1 == timestamp_start and e_1 == timestamp_end):
            start_shift = random.choices(list(position_probs_start.keys()), list(position_probs_start.values()))[0]
            s_1 = timestamp_start + (start_shift * duration)

            max_retries = 20
            retries1 = 0
            retries2 = 0

            while (s_1 < 0 or s_1 >= duration) and retries1 < max_retries:
                start_shift = random.choices(list(position_probs_start.keys()), list(position_probs_start.values()))[0]
                s_1 = timestamp_start + (start_shift * duration)
                retries1 += 1

            if retries1 >= max_retries:
                s_1 = 0
                print(video_id)

            interval = random.choices(list(interval_shifts.keys()), list(interval_shifts.values()))[0]
            e_1 = s_1 + (interval * (timestamp_end - timestamp_start))
            while (e_1 >= duration) and retries2 < max_retries:
                interval = random.choices(list(interval_shifts.keys()), list(interval_shifts.values()))[0]
                e_1 = s_1 + (interval * (timestamp_end - timestamp_start))
                retries2 += 1

            if e_1 > duration:
                e_1 = duration

        if (e_1 - s_1) < (timestamp_end - timestamp_start):
            cou += 1
            print(video_id)
            print(duration)
            print(s_1)
            print(e_1)
            print(timestamp_start)
            print(timestamp_end)
        if s_1 == timestamp_start and e_1 == timestamp_end:
            cou+=1
            print(f"构造的区间与真值区间一样: {video_id}")
                # continue
        if (e_1 - s_1) / duration <= 0.1:
            cou+=1

        elif (e_1 - s_1) / duration > 0.9:
            couu+=1
        else:
            couuu+=1
            print(video_id)
            print((e_1 - s_1) / duration)


        question_template = random.choice(question_variants2)
        question = question_template.replace('{sentence_id}', sentence_id)

        # 添加问题到 conversations 列表
        conversations.append({"from": "human", "value": question})

        # 构造回答形式的字符串
        answer = f"{sentence_id} occurs from <s0> to <e0>."
        answer = answer[0].capitalize() + answer[1:]
        # 添加回答到 conversations 列表
        conversations.append({"from": "gpt", "value": answer})

        # 构造 meta 数据
        meta = {
            "duration": duration,
            "token": {
                "<s-1>": s_1,
                "<e-1>": e_1,
                "<s0>": timestamp_start,
                "<e0>": timestamp_end
            }
        }

        # 构造输出数据
        output_json = {
            "id": video_id,
            "conversations": conversations,
            "meta": meta,
            "source": "anet"
        }

        # 添加到输出数据列表
        output_data.append(output_json)
    else:
        print(f"Missing sentence_id for video_id: {video_id}")
print(cou, count, cou / count)
print(couu,count,couu/count)
print(couuu,count,couuu/count)
# 输出或存储结果
# with open(
#         '/home/shige4090/lxf/LXF/VTimeLLM/data/8.18_activitynet_long_distribution_law.json',
#         'w', encoding='utf-8') as outfile:
#     json.dump(output_data, outfile, indent=4, ensure_ascii=False)
