import json
import re


def time(answer):
    matches = re.search(r"(\d{2}) (to|and) (\d{2})", answer)
    if not matches:
        return 0, 0
    from_number = float(matches.group(1)) / 100
    to_number = float(matches.group(3)) / 100
    return from_number, to_number


def write_log(log_path, video_id, data_duration, timestamp, predicate_time, sentence):
    log = {

        'video_id': video_id,
        "duration": data_duration,
        "timestamp": timestamp,
        "predicate_time": predicate_time,
        "sentence_id": sentence,
    }
    with open(log_path, 'a') as f:
        f.write(json.dumps(log) + '\n')


# 定义要读取的文件路径


data_path = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/data/activitynet/train.json'

# long = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/long_8.18.txt'
short = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/8_22_filtered_data/8_22_new_short.txt'
# left = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/left.txt'
# right = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/right.txt'
# 打开文件并逐行读取内容

# log_path_too_long = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_16_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/too_long_0.15.txt'
log_path_too_short = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/8_22_filtered_data/8_22_new_short.json'
# log_path_too_left = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_16_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/too_left_0.31.txt'
# log_path_too_right = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_16_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/too_right_0.10.txt'
# 打开文件并逐行读取内容
cou = 0
count = 0
counttt = 0
count_too_long, count_too_short, count_too_left, count_too_right = 0, 0, 0, 0
with open(data_path, 'r', encoding='utf-8') as data_file:
    data_data = json.load(data_file)
with open(log_path_too_short, 'r', encoding='utf-8') as file:
    for line in file:
        data = json.loads(line.strip())
        cou += 1
        video_id = data['video_id']
        sentence_id = data["sentence_id"]
        predicate_time = data["predicate_time"]
        answer = data['answer']
        start_time, end_time = time(answer)

        for key, value in data_data.items():
            data_video_id = key
            if video_id == data_video_id:
                data_duration = value['duration']
                data_timestamps = value['timestamps']
                timestamp = data_timestamps[sentence_id]
                data_sentences = value['sentences']
                sentence = data_sentences[sentence_id]

                write_log(short, video_id, data_duration, timestamp, predicate_time, sentence)

        # count = 0
        # count_too_long, count_too_short, count_too_left, count_too_right = 0, 0, 0, 0

        count += 1
        # write_log(log_path_too_right, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
print(cou)
print(count)
print(count / cou)
