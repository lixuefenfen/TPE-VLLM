import json
import random
import string


# 定义时间前移的比例
start_time_shifts = {
    -70.0: 5.92,
    -60.0: 7.58,
    -50.0: 8.62,
    -40.0: 10.72,
    -30.0: 12.75,
    -20.0: 14.57,
    -10.0: 7.63
}

end_time_shifts = {
    -70.0: 6.46,
    -60.0: 7.45,
    -50.0: 7.86,
    -40.0: 8.30,
    -30.0: 8.78,
    -20.0: 9.25,
    -10.0: 6.45
}

question_variants = [
    '<video>\nDoes event {sentence_id} occur from <s-1> to <e-1> frames?',
    '<video>\nIs the event {sentence_id} happening between frames <s-1> and <e-1>?',
    '<video>\nCan you observe {sentence_id} in the frame range from <s-1> to <e-1>?',
    '<video>\nDuring which frames does the event {sentence_id} take place? From frame <s-1> to frame <e-1>?',
    '<video>\nIs {sentence_id} visible between frames <s-1> and <e-1> in the video?',
    '<video>\nCan the event {sentence_id} be seen from frame <s-1> to frame <e-1>?',
    '<video>\nIs {sentence_id} taking place between frames <s-1> and <e-1> in this video?',
    '<video>\nDoes the video capture {sentence_id} happening between frames <s-1> and <e-1>?',
    '<video>\nIs there evidence of {sentence_id} from frame <s-1> to <e-1>?',
    '<video>\nIdentify if the event {sentence_id} is occurring between frames <s-1> and <e-1>.',
    '<video>\nDoes the sequence from frame <s-1> to <e-1> show {sentence_id}?',
    '<video>\nIs {sentence_id} observable between frames <s-1> and <e-1>?',
    '<video>\nCheck whether {sentence_id} is happening within frames <s-1> to <e-1>.',
    '<video>\nCan {sentence_id} be detected from frame <s-1> to <e-1> in the video?',
    '<video>\nIs the action {sentence_id} visible between frames <s-1> and <e-1>?'
]

# 读取文件中的所有行
with open('/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/left.txt', 'r', encoding='utf-8') as file:
    lines = file.readlines()

# # 计算要采样的行数
# sample_size = len(lines) // 3
#
# # 随机抽取三分之一的数据行
# sampled_lines = random.sample(lines, sample_size)

output_data = []

# 处理采样的数据
for line in lines:
    data = json.loads(line.strip())
    video_id = data['video_id']
    duration = data["duration"]
    sentence_id = data.get("sentence_id", None)  # 使用 .get 方法来安全地获取 sentence_id
    # predicate_time = data["predicate_time"]
    timestamp = data["timestamp"]
    conversations = []

    if sentence_id:
        # 去除 sentence_id 前面的空格
        sentence_id = sentence_id.lstrip()
        sentence_id = sentence_id[0].lower() + sentence_id[1:]
        sentence_id = sentence_id.rstrip(string.punctuation)
        # predicate_time_start = predicate_time[0]
        # predicate_time_end = predicate_time[1]
        timestamp_start = timestamp[0]
        timestamp_end = timestamp[1]


        # 根据比例随机选择时间前移量
        start_shift = random.choices(list(start_time_shifts.keys()), list(start_time_shifts.values()))[0]
        end_shift = random.choices(list(end_time_shifts.keys()), list(end_time_shifts.values()))[0]

        s_1 = timestamp_start + start_shift
        # e_1 = timestamp_end + end_shift
        max_retries = 10
        retries1 = 0
        retries2 = 0
        while s_1 <0 and retries1 < max_retries:
            start_shift = random.choices(list(start_time_shifts.keys()), list(start_time_shifts.values()))[0]
            s_1 = timestamp_start + start_shift
            retries1 += 1

        if retries1 >= max_retries:
            s_1 = 0
            print(video_id)
        # 计算前移后的时间

        e_1 = s_1 + (timestamp_end - timestamp_start)
        if e_1 > timestamp_start:
            e_1 = timestamp_start
        # 确保 e_1 大于 s_1，设置最大重试次数

        # while e_1 <= s_1 and retries2 < max_retries:
        #     end_shift = random.choices(list(end_time_shifts.keys()), list(end_time_shifts.values()))[0]
        #     e_1 = timestamp_end + end_shift
        #     retries2 += 1
        #
        # # 如果在最大重试次数内仍然无法满足条件，跳过该数据项
        # if retries2 >= max_retries:
        #     e_1 = timestamp_end - timestamp_start
        #

        question_template = random.choice(question_variants)
        question = question_template.replace('{sentence_id}', sentence_id)

        # 添加问题到 conversations 列表
        conversations.append({"from": "human", "value": question})

        # 构造回答形式的字符串
        answer = f"No, {sentence_id} occurs from <s0> to <e0>."

        # 添加回答到 conversations 列表
        conversations.append({"from": "gpt", "value": answer})



        # 构造 meta 数据
        meta = {
            "duration": duration,
            "token": {
                # "<s-1>": predicate_time_start,
                # "<e-1>": predicate_time_end,
                "<s-1>": s_1,
                "<e-1>": e_1,
                "<s0>": timestamp_start,
                "<e0>": timestamp_end
            }
        }

        # 构造输出数据
        output_json = {
            "id": video_id,
            "conversations": conversations,
            "meta": meta,
            "source": "anet"
        }

        # 添加到输出数据列表
        output_data.append(output_json)
    else:
        print(f"Missing sentence_id for video_id: {video_id}")

# 输出或存储结果
# with open('/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/add_data_left_02.json', 'w', encoding='utf-8') as outfile:
#     json.dump(output_data, outfile, indent=4, ensure_ascii=False)