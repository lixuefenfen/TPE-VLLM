import json
import random
import string

# 定义时间前移的比例
start_time_shifts = {
    150.0: 2.62,
    140.0: 2.39,
    130.0: 2.86,
    120.0: 3.09,
    110.0: 3.92,
    100.0: 4.48,
    90.0: 5.04,
    80.0: 5.72,
    70.0: 6.01,
    60.0: 6.25,
    50.0: 6.87,
    40.0: 7.54,
    30.0: 9.46,
    20.0: 9.87,
    10.0: 9.90
    # 0: 6.25
}

end_time_shifts = {
    150.0: 2.15,
    140.0: 2.21,
    130.0: 2.36,
    120.0: 2.74,
    110.0: 3.33,
    100.0: 3.42,
    90.0: 4.15,
    80.0: 4.86,
    70.0: 4.77,
    60.0: 5.89,
    50.0: 7.72,
    40.0: 9.07,
    30.0: 11.28,
    20.0: 12.67,
    10.0: 11.40
    # 0: 5.54
}

question_variants = [
    '<video>\nDoes event {sentence_id} occur from <s-1> to <e-1> frames?',
    '<video>\nIs the event {sentence_id} happening between frames <s-1> and <e-1>?',
    '<video>\nCan you observe {sentence_id} in the frame range from <s-1> to <e-1>?',
    '<video>\nDuring which frames does the event {sentence_id} take place? From frame <s-1> to frame <e-1>?',
    '<video>\nIs {sentence_id} visible between frames <s-1> and <e-1> in the video?',
    '<video>\nCan the event {sentence_id} be seen from frame <s-1> to frame <e-1>?',
    '<video>\nIs {sentence_id} taking place between frames <s-1> and <e-1> in this video?',
    '<video>\nDoes the video capture {sentence_id} happening between frames <s-1> and <e-1>?',
    '<video>\nIs there evidence of {sentence_id} from frame <s-1> to <e-1>?',
    '<video>\nIdentify if the event {sentence_id} is occurring between frames <s-1> and <e-1>.',
    '<video>\nDoes the sequence from frame <s-1> to <e-1> show {sentence_id}?',
    '<video>\nIs {sentence_id} observable between frames <s-1> and <e-1>?',
    '<video>\nCheck whether {sentence_id} is happening within frames <s-1> to <e-1>.',
    '<video>\nCan {sentence_id} be detected from frame <s-1> to <e-1> in the video?',
    '<video>\nIs the action {sentence_id} visible between frames <s-1> and <e-1>?'
]

# 读取文件中的所有行
with open(
        '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/right.txt',
        'r', encoding='utf-8') as file:
    lines = file.readlines()

# # 计算要采样的行数
# sample_size = len(lines) // 3
#
# # 随机抽取三分之一的数据行
# sampled_lines = random.sample(lines, sample_size)

output_data = []

# 处理采样的数据
for line in lines:
    data = json.loads(line.strip())
    video_id = data['video_id']
    duration = data["duration"]
    sentence_id = data.get("sentence_id", None)  # 使用 .get 方法来安全地获取 sentence_id
    # predicate_time = data["predicate_time"]
    timestamp = data["timestamp"]
    conversations = []

    if sentence_id:
        # 去除 sentence_id 前面的空格
        sentence_id = sentence_id.lstrip()
        sentence_id = sentence_id[0].lower() + sentence_id[1:]
        sentence_id = sentence_id.rstrip(string.punctuation)
        # predicate_time_start = predicate_time[0]
        # predicate_time_end = predicate_time[1]
        timestamp_start = timestamp[0]
        timestamp_end = timestamp[1]

        method = random.choice([1, 2])

        if method == 1:
            start_shift = random.choices(list(start_time_shifts.keys()), list(start_time_shifts.values()))[0]
            end_shift = random.choices(list(end_time_shifts.keys()), list(end_time_shifts.values()))[0]
            s_1 = timestamp_start + start_shift
            e_1 = min(timestamp_end + end_shift, duration)

            max_retries = 30
            retries = 0
            while e_1 <= s_1 and retries < max_retries:
                start_shift = random.choices(list(start_time_shifts.keys()), list(start_time_shifts.values()))[0]
                s_1 = timestamp_start + start_shift
                retries += 1

            if retries >= max_retries:
                s_1 = e_1 - (timestamp_end - timestamp_start)



                # raise ValueError(
                #     f"Failed to find a valid shift for start time after {max_retries} retries for video_id: {video_id}")

        else:

            start_shift = random.choices(list(start_time_shifts.keys()), list(start_time_shifts.values()))[0]
            # end_shift = random.choices(list(end_time_shifts.keys()), list(end_time_shifts.values()))[0]

            s_1 = timestamp_start + start_shift
            # e_1 = timestamp_end + end_shift
            max_retries = 30
            retries1 = 0

            while s_1 >=duration and retries1 < max_retries:
                start_shift = random.choices(list(start_time_shifts.keys()), list(start_time_shifts.values()))[0]
                s_1 = timestamp_start + start_shift
                retries1 += 1

            if retries1 >= max_retries:
                e_1 = duration
                s_1 = e_1 - (timestamp_end - timestamp_start)
                # print(video_id)
            # 计算前移后的时间

            e_1 = min(s_1 + (timestamp_end - timestamp_start), duration)
            if s_1 < timestamp_end and e_1 < timestamp_end :
                s_1 = timestamp_end
            if e_1 < s_1:
                e_1 = duration



        question_template = random.choice(question_variants)
        question = question_template.replace('{sentence_id}', sentence_id)

        # 添加问题到 conversations 列表
        conversations.append({"from": "human", "value": question})

        # 构造回答形式的字符串
        answer = f"No, {sentence_id} occurs from <s0> to <e0>."

        # 添加回答到 conversations 列表
        conversations.append({"from": "gpt", "value": answer})

        # 构造 meta 数据
        meta = {
            "duration": duration,
            "token": {
                # "<s-1>": predicate_time_start,
                # "<e-1>": predicate_time_end,
                "<s-1>": s_1,
                "<e-1>": e_1,
                "<s0>": timestamp_start,
                "<e0>": timestamp_end
            }
        }

        # 构造输出数据
        output_json = {
            "id": video_id,
            "conversations": conversations,
            "meta": meta,
            "source": "anet"
        }

        # 添加到输出数据列表
        output_data.append(output_json)
    else:
        print(f"Missing sentence_id for video_id: {video_id}")

# 输出或存储结果
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/8.16_activitynet_right_distribution_law.json', 'w', encoding='utf-8') as outfile:
    json.dump(output_data, outfile, indent=4, ensure_ascii=False)
