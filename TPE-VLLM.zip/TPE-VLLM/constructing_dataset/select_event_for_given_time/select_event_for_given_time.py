import json
import math
import random
import string

question_variants = [
    '<video>\nPlease select one of the following events that occurred from <s0> to <e0> in the video.',
    '<video>\nPlease select one of the following events that takes place from <s0> to <e0> in the video.',
    '<video>\nFrom the list of events provided below, please identify and select the one that occurs in the video between <s0> and <e0>.',
    '<video>\nIdentify the event that takes place in the video between <s0> and <e0> from the list provided.',
    '<video>\nWhich of the following events occurs in the video segment spanning from <s0> to <e0>?',
    '<video>\nAnalyze the video content between <s0> and <e0>, and determine which listed event matches this segment.',
    '<video>\nIn the portion of the video from <s0> to <e0>, which of these events can be observed?',
    '<video>\nFrom the provided array of events, select a event that occurred from <s0> to <e0> in the video.',
    "<video>\nWhich event from the given options accurately describes the action in the video between <s0> and <e0>?",
    '<video>\nDuring the timespan of <s0> to <e0> in the video, which of the following events can be seen?',
    '<video>\nAmong the given events, choose the one that occurs in the video during the interval from <s0> to <e0>.',
    '<video>\nPlease select a event from the provided list that best characterizes the video segment between <s0> and <e0>.',
    '<video>\nAnalyze the video sequence between frames <s0> and <e0>, and match it to one of the listed events.',
    '<video>\nAmong the provided event descriptions, which one accurately represents the action occurring in the video between <s0> and <e0>?',
    "<video>\nOf the following events, which one best accurately describes the content from <s0> and <e0> of video."
]


# question2 = "Event 1: {sentences_1} Event 2: {sentences_2} Event 3: {sentences_3}. Spans 1: From <s1> to <e1>. Spans 2: From <s2> to <e2>. Spans 3: From <s3> to <e3>."
def find_span_index(spans, target, tolerance=1e-6):
    for i, (s, e) in enumerate(spans):
        if math.isclose(s, target[0], rel_tol=tolerance) and math.isclose(e, target[1], rel_tol=tolerance):
            return i
    return -1
    # 如果没有找到匹配的span，返回-1


def create_dialogue_data(filtered_data):
    output_data = []
    for video_id, video_info in filtered_data.items():
        timestamps = video_info['timestamps']
        sentences = video_info['sentences']
        duration = video_info["duration"]
        processed_sentences = []
        conversations = []
        for sentence in sentences:
            sentence = sentence.lstrip()
            sentence = sentence[0].capitalize() + sentence[1:]
            # sentence = sentence.rstrip(string.punctuation)
            processed_sentences.append(sentence)

        question_template = random.choice(question_variants)

        selected_index = random.randint(0, len(timestamps) - 1)

        correct_sentence = processed_sentences[selected_index]

        # 随机打乱时间戳
        shuffled_sentences = processed_sentences.copy()
        random.shuffle(shuffled_sentences)

        question = question_template.replace("<s0>", f"<s{selected_index}>").replace("<e0>", f"<e{selected_index}>")
        for i, sentence in enumerate(shuffled_sentences):
            question += f" Event {i + 1}: {sentence}"

        # 构造答案3
        correct_index = shuffled_sentences.index(correct_sentence)
        answer = f"The event that occurs in the video between <s{selected_index}> and <e{selected_index}> is: {correct_sentence} This corresponds to option event {correct_index + 1} in the list."


        conversations.append({"from": "human", "value": question})
        conversations.append({"from": "gpt", "value": answer})

        meta = {
            "duration": duration,
            "token": {}
        }
        for i, (start, end) in enumerate(timestamps):
            meta["token"][f"<s{i}>"] = start
            meta["token"][f"<e{i}>"] = end
        output_json = {
            "id": video_id,
            "conversations": conversations,
            "meta": meta,
            "source": "anet"
        }
        output_data.append(output_json)
    return output_data

# 读取过滤后的数据
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/select_event_for_given_time/filter_anet_train_data.json', 'r') as f:
    filtered_data = json.load(f)

# 创建对话数据
dialogue_data = create_dialogue_data(filtered_data)

# 将对话数据写入新文件
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/select_event_for_given_time/select_event_for_given_time.json', 'w', encoding='utf-8') as f:
    json.dump(dialogue_data, f, ensure_ascii=False, indent=2)

print(f"Generated dialogue data for {len(dialogue_data)} videos.")