import json

file_path1 = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/data/activitynet/train.json'
# file_path2 = "/home/shige4090/lxf/LXF/VTimeLLM/data/original_anet_data/8.18_activitynet_short_distribution_law.json"
file_path2 = '/home/shige4090/lxf/LXF/VTimeLLM/data/task01_event_time_match/anet_train.json'
import json
with open(file_path2, 'r') as f:
    data1 = json.load(f)
video_id1 = []

for id , info in data1.items():
    video_id1.append(id)
print(len(video_id1))
def word_count(sentence):
    """计算句子中的单词数量"""
    return len(sentence.split())

def calculate_iou(timestamp1, timestamp2):
    """计算两个时间戳的交并比"""
    start1, end1 = timestamp1
    start2, end2 = timestamp2

    intersection = max(0, min(end1, end2) - max(start1, start2))
    union = max(end1, end2) - min(start1, start2)

    if union == 0:
        return 0
    return intersection / union

def filter_data(data, video_id1):
    filtered_data = {}
    cou = 0
    for video_id, video_info in data.items():
        duration = video_info['duration']
        timestamps = video_info['timestamps']
        sentences = video_info['sentences']

        filtered_timestamps = []
        filtered_sentences = []

        if duration < 10 or duration > 200:
            # cou+=1  #1562
            continue

        for (start, end), sentence in zip(timestamps, sentences):
            if word_count(sentence) > 40:
                # cou += 1
                # print(f"Skipping sentence in video {video_id} due to excessive word count")
                continue
            should_skip = False
            if (end - start) < duration* 0.06 or (end - start) > duration * 0.94:
                # print(video_id)
                continue
            for prev_start, prev_end in filtered_timestamps:
                iou = calculate_iou((start, end), (prev_start, prev_end))
                if iou > 0.9:
                    should_skip = True
                    # print(f"Skipping timestamp {start}-{end} in video {video_id} due to high IoU")
                    break
                if start == prev_start or end == prev_end:
                    # print(video_id)
                    cou+=1
                    should_skip = True
                    break

            if not should_skip:
                filtered_timestamps.append((start, end))
                filtered_sentences.append(sentence)



        # 检查过滤后的时间戳数量
        if len(filtered_timestamps) < 3 or len(filtered_timestamps) > 5 :
            continue


        if video_id in video_id1:
            continue


        # 保存过滤后的数据
        filtered_data[video_id] = {
            "duration": duration,
            "timestamps": filtered_timestamps,
            "sentences": filtered_sentences
        }

    print(cou)
    return filtered_data


# 读取原始数据
with open(file_path1, 'r') as f:
    data = json.load(f)

# 过滤数据
filtered_data = filter_data(data, video_id1)

# 将过滤后的数据写入新文件
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/task02_order_for_events/9.5_new_anet_train_data.json', 'w') as f:
    json.dump(filtered_data, f)


print(f"Original data count: {len(data)}")
print(f"Filtered data count: {len(filtered_data)}")










#
# import json
# import os
#
# file_path = "/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/data/activitynet/train.json"
# folder_path = "/home/shige4090/lxf/LXF/VTimeLLM/pre-extracted_feature/stage3_clip_feat"  # 请替换为你要检查的文件夹路径
# import json
# import os
#
# # file_path = "/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/data/activitynet/train.json"
# # folder_path = "/path/to/your/folder"  # 请替换为你要检查的文件夹路径
#
# # 读取 JSON 文件
# with open(file_path, 'r', encoding='utf-8') as data_file:
#     data_data = json.load(data_file)
#
# # 获取文件夹中的所有文件名（去掉后缀）
# folder_files = set(os.path.splitext(filename)[0] for filename in os.listdir(folder_path))
#
# # 计数器
# match_count = 0
# total_count = 0
# missing_ids = []
#
# # 遍历 JSON 数据
# for data_video_id in data_data.keys():
#     total_count += 1
#     if data_video_id in folder_files:
#         match_count += 1
#     else:
#         missing_ids.append(data_video_id)
#
# # 打印结果
# print(f"JSON 文件中的视频 ID 总数：{total_count}")
# print(f"与文件夹中文件名匹配的视频 ID 数：{match_count}")
# print(f"匹配比例：{match_count / total_count:.2%}")
#
# # 打印缺失的视频 ID
# print(f"\n在文件夹中没有找到的视频 ID 数量：{len(missing_ids)}")
# if missing_ids:
#     print("缺失的视频 ID 列表：")
#     for id in missing_ids:
#         print(id)
#
# # 可选：将缺失的视频 ID 写入文件
# with open("/home/shige4090/lxf/LXF/VTimeLLM/missing_video_feature_anet.txt", "w") as f:
#     for id in missing_ids:
#         f.write(f"{id}\n")
# print("\n缺失的视频 ID 已写入 'missing_video_ids.txt' 文件")
#
#
#


















