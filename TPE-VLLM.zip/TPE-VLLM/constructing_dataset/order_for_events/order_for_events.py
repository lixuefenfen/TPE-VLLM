import json
import math
import random
import string

question_variants1 = [
    '<video>\nBased on the video content, sort these event descriptions according to their chronological sequence. ',
    '<video>\nThe video presents a series of events. Please order them based on their temporal progression. ',
    '<video>\nCan you arrange the following events in the order they occurred in the video? ',
    '<video>\nThe video presents a series of events. Could you please order them based on their temporal progression? ',
    '<video>\nPlease sequence the following events based on their occurrence in the video timeline. ',
    '<video>\nThe following statements describe various moments in the video. Arrange them in the correct sequential order. ',
    '<video>\nBased on your observation of the video, please arrange these event descriptions in their temporal order. ',
    '<video>\nGiven the events portrayed in the video, what would be your approach to arranging them in a timeline? ',
    "<video>\nIf tasked with creating a timeline of the video's events, how would you order the following descriptions? ",
    '<video>\nThe following events represent the content of a particular moment in the video. Please rank these events in order of their occurrence. ',
    '<video>\nThe following event expressed a specific moment in video content, please according to the order of events will be ordered by these events. ',
    '<video>\nThe events listed below depict specific moments from the video. Can you arrange them in the order they occurred? ',
    '<video>\nThe following descriptions capture pivotal moments in the footage. What would be their correct temporal sequence? ',
    '<video>\nThe following events are drawn from different parts of the video. Your goal is to place them in their proper chronological order. ',
    "<video>\nAs you recall the video's timeline, how would you order these events to accurately represent their occurrence? "
]

# question2 = "Event 1: {sentences_1} Event 2: {sentences_2} Event 3: {sentences_3}. Spans 1: From <s1> to <e1>. Spans 2: From <s2> to <e2>. Spans 3: From <s3> to <e3>."
def find_span_index(spans, target, tolerance=1e-6):
    for i, (s, e) in enumerate(spans):
        if math.isclose(s, target[0], rel_tol=tolerance) and math.isclose(e, target[1], rel_tol=tolerance):
            return i
    return -1
    # 如果没有找到匹配的span，返回-1


output_data = []

def create_dialogue_data(filtered_data):
    output_data = []
    for video_id, video_info in filtered_data.items():
        timestamps = video_info['timestamps']
        sentences = video_info['sentences']
        duration = video_info["duration"]
        processed_sentences = []
        conversations = []
        for sentence in sentences:
            sentence = sentence.lstrip()
            sentence = sentence[0].capitalize() + sentence[1:]
            processed_sentences.append(sentence)

        original_pairs = list(zip(processed_sentences, timestamps))

        # 打乱events的顺序
        shuffled_events = processed_sentences.copy()
        random.shuffle(shuffled_events)

        question_template = random.choice(question_variants1)

        # 构造问题
        question = question_template
        for i, sent in enumerate(shuffled_events, 1):
            question += f"Event {i}: {sent} "
        question = question.rstrip()

        # 构造答案
        answer = "According to the video content, the sequence of events should be: "
        sorted_events = sorted(original_pairs, key=lambda x: x[1][0])

        for i, (event, _) in enumerate(sorted_events, 1):
            event_index = shuffled_events.index(event) + 1
            answer += f"Event {event_index}, "

        answer = answer.rstrip(", ") + "."

        conversations.append({"from": "human", "value": question})
        conversations.append({"from": "gpt", "value": answer})




        output_json = {
            "id": video_id,
            "conversations": conversations,
            "source": "anet"
        }
        output_data.append(output_json)
    return output_data


# 读取过滤后的数据
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/order_for_events/anet_train_data.json', 'r') as f:
    filtered_data = json.load(f)

# 创建对话数据
dialogue_data = create_dialogue_data(filtered_data)

# 将对话数据写入新文件
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/order_for_events/8.28_order_for_events.json', 'w', encoding='utf-8') as f:
    json.dump(dialogue_data, f, ensure_ascii=False, indent=2)

print(f"Generated dialogue data for {len(dialogue_data)} videos.")