#!/bin/bash

MODEL_VERSION=vicuna-v1-5-
gpu_vis=0 # per_device_train_batch_size * gradient_accumulation_steps * n_gpus = 128
MASTER_PORT=29570


deepspeed --include localhost:$gpu_vis --master_port $MASTER_PORT /home/shige4090/lxf/LXF/VTimeLLM/vtimellm/train/train_mem.py \
    --deepspeed /home/shige4090/lxf/LXF/VTimeLLM/scripts/zero2.json \
    --lora_enable True \
    --training_stage 3 \
    --model_name_or_path /home/shige4090/lxf/LXF/VTimeLLM/checkpoints/vicuna-7b-v1.5 \
    --version v1 \
    --data_path /home/shige4090/lxf/LXF/VTimeLLM/data/ablation/remove_left_right.json \
    --feat_folder /home/shige4090/lxf/pre-extracted_feature/stage3_clip_feat_new \
    --pretrain_mm_mlp_adapter /home/shige4090/lxf/LXF/VTimeLLM/checkpoints/fuxian-vtimellm-$MODEL_VERSION-stage1/mm_projector.bin \
    --stage2_path /home/shige4090/lxf/LXF/VTimeLLM/checkpoints/fuxian-vtimellm-$MODEL_VERSION-stage2 \
    --output_dir /home/shige4090/lxf/LXF/VTimeLLM/checkpoints/remove_left_right \
    --bf16 True \
    --num_train_epochs 2 \
    --per_device_train_batch_size 8 \
    --gradient_accumulation_steps 16 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 50000 \
    --save_total_limit 1 \
    --learning_rate 1e-4 \
    --freeze_mm_mlp_adapter True \
    --lora_r 64 \
    --lora_alpha 128 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --tf32 True \
    --model_max_length 2048 \
    --gradient_checkpointing True \
    --dataloader_num_workers 4 \
    --lazy_preprocess True \
    --report_to wandb
