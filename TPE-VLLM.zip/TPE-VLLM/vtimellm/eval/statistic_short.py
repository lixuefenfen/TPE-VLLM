import json
import re


def time(answer):
    matches = re.search(r"(\d{2}) (to|and) (\d{2})", answer)
    if not matches:
        return 0, 0
    from_number = float(matches.group(1)) / 100
    to_number = float(matches.group(3)) / 100
    return from_number, to_number


def write_log(log_path, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt):
    log = {
        "count": count,
        'video_id': video_id,
        "sentence_id": sentence_id,
        "iou": iou,
        "predicate_time": predicate_time,
        "gt_timestamp": timestamp,
        'answer': answer,
        "gt": gt
    }
    with open(log_path, 'a') as f:
        f.write(json.dumps(log) + '\n')


# 定义要读取的文件路径
file_path = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/short.txt'

# 打开文件并逐行读取内容
cou = 0
count = 0
count_00 =0
count_000 =0
count_mid = 0
count_0 = 0
count_1 = 0
count_2 = 0
count_3 =0
counttt = 0
count_too_long, count_too_short, count_too_left, count_too_right = 0, 0, 0, 0

import json

# 读取 JSON 文件
with open(file_path, 'r', encoding='utf-8') as file:
    for line in file:
        data = json.loads(line)
        video_id = data['video_id']
        timestamp = data["timestamp"]
        gt_start = timestamp[0]
        gt_end = timestamp[1]
        predicate_time = data["predicate_time"]
        pred_start = predicate_time[0]
        pred_end = predicate_time[1]

        cou += 1
        # if (pred_end - pred_start) >= ((gt_end - gt_start) * 3):
        #     count_too_long += 1
        #     # write_log(log_path_too_long, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
        # if ((pred_end - pred_start) * 3) <= gt_end - gt_start:
        #     count_too_short += 1
        #     # write_log(log_path_too_short, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
        if pred_start > gt_start and pred_end < gt_end:
            count_mid += 1

        if pred_start == gt_start:
            count_00 += 1
        if pred_start < gt_start:
            count_0 +=1
        if pred_start > gt_start:
            count_1 += 1

        if pred_end == gt_end:
            count_000 +=1
        if pred_end < gt_end:
            count_2 += 1
        if pred_end >= gt_end:
            count_3 +=1
        # if gt_start - pred_end > 0:
        #     count_too_left += 1
        #     # write_log(log_path_too_left, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
        # if pred_start - gt_end > 0:
        #     count_too_right += 1
            # write_log(log_path_too_right, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)

print(f"总共有 {cou} 条数据;\n"
      # f"长度偏长的有 {count_too_long} 个，比例为 {round(count_too_long / cou, 2)};\n"
      # f"长度偏短的有 {count_too_short} 个，比例为 {round(count_too_short / cou, 2)};\n"
      f"预测开始时间等于真值开始时间的有 {count_00} 个，比例为{round(count_00 / cou, 2)};\n"
      f"预测开始时间在真值开始时间之前的有 {count_0} 个，比例为{round(count_0 / cou, 2)};\n"
      f"预测开始时间在真值开始时间之后的有 {count_1} 个，比例为{round(count_1 / cou, 2)};\n\n"
      f"预测结束时间等于真值结束时间的有 {count_000} 个，比例为{round(count_000 / cou, 2)};\n"
      f"预测结束时间在真值结束时间之前的有 {count_2} 个，比例为{round(count_2 / cou, 2)};\n"
      f"预测结束时间在真值开始时间之后的有 {count_3} 个，比例为{round(count_3 / cou, 2)};\n"
      f"预测区间在真值区间之间的有 {count_mid} 个，比例为{round(count_mid / cou, 2)};\n"

      f"长度偏左的有 {count_too_left} 个，比例为 {round(count_too_left / cou, 2)};\n"
      f"长度偏右的有 {count_too_right} 个，比例为 {round(count_too_right / cou, 2)};")
