import json
output_data = []
# 打开并读取 JSON 文件
# with open('/home/shige4090/lxf/LXF/VTimeLLM/data/VideoInstruct100K.json', 'r', encoding='utf-8') as file1:
#     data1 = json.load(file1)
# with open('/home/shige4090/lxf/LXF/VTimeLLM/data/stage3.json', 'r', encoding='utf-8') as file2:
#     data2 = json.load(file2)
#     filtered_data = [entry for entry in data2 if 'meta' in entry]
#
#     with open('/home/shige4090/lxf/LXF/VTimeLLM/data/stage3_delete_VideoInstruct.json', 'w', encoding='utf-8') as file:
#         json.dump(filtered_data, file, ensure_ascii=False, indent=4)
#
#     print("Filtered data has been saved to 'filtered_file.json'.")
with open('/home/shige4090/lxf/LXF/VTimeLLM/data/stage3_delete_VideoInstruct.json', 'r', encoding='utf-8') as file2:
    data2 = json.load(file2)
entry_count = len(data2)

print(f"Number of entries in the dataset: {entry_count}")




    # for entry in data1:
    #     question = entry['q']
    #     answer = entry['a']
    #     video_id1 = entry['video_id']
    #     for data in data2:
    #         video_id2 = data['id']
    #         conversations = data['conversations']
    #         duration = data['meta']['duration']
    #         for convo in conversations:
    #             speaker = convo['from']
    #             message = convo['value']
    #
    #             print(f"{speaker.title()}: {message}")




# # 输出或存储结果
# with open('/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/jioj.json', 'w', encoding='utf-8') as outfile:
#     json.dump(output_data, outfile, indent=4, ensure_ascii=False)
# # 逐条读取内容


