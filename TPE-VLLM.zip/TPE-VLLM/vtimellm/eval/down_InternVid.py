import json
import os
import sys
import subprocess
import threading
import urllib

from pytube import YouTube
from tqdm import tqdm
import ssl
import urllib.request

def progress(s, chunk, bytes_remaining):
    download_percent = int((s.filesize - bytes_remaining) / s.filesize * 100)
    sys.stdout.write(f'\rProgress: {download_percent} %')
    sys.stdout.flush()


def complete(s, file_path):
    print(f'Download complete: {file_path}')


def download_video(youtube_id, custom_filename, download_path):
    output_file = os.path.join(download_path, custom_filename)
    if os.path.exists(output_file):
        print(f'视频 {youtube_id} 已经存在，跳过下载。')
        return

    try:
        url = f'https://www.youtube.com/watch?v={youtube_id}'
        command = [
            'yt-dlp',
            '--no-check-certificate',
            '-o', os.path.join(download_path, custom_filename),
            url
        ]
        subprocess.run(command, check=True)
        print(f'视频 {youtube_id} 下载完成，保存路径为：{output_file}')
    except subprocess.CalledProcessError as e:
        print(f'下载视频 {youtube_id} 时发生了未知错误：{e}')
        return
# def download_video(youtube_id, custom_filename,download_path):
#     output_file = custom_filename  # 输出文件名
#     # 检查文件是否已经存在
#     if os.path.exists(output_file):
#         print(f'视频 {youtube_id} 已经存在，跳过下载。')
#         return
#     try:
#         youtube_video = YouTube(f'https://www.youtube.com/watch?v={youtube_id}', on_progress_callback=progress,
#                                 on_complete_callback=complete)
#         video_stream = youtube_video.streams.get_highest_resolution()
#         print(f'开始下载，视频{youtube_id}大小为{video_stream.filesize_mb:.2f}MB')  # 保留两位小数
#         video_path = video_stream.download(output_path=download_path, filename=custom_filename)
#         print(f'视频 {youtube_id} 下载完成，保存路径为：{video_path}')
#     except Exception as e:  # 添加这一行来捕获所有的异常
#         print(f'下载视频 {youtube_id} 时发生了未知错误：{e}')  # 打印出异常的详细信息
#         return


def read_json_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"The file {file_path} does not exist.")
        return None
    except json.JSONDecodeError:
        print("Error decoding JSON from the file.")
        return None

    # 使用示例


if __name__ == '__main__':
    import ssl

    ssl._create_default_https_context = ssl._create_unverified_context
    cou = 0
    file_path = "/home/shige4090/lxf/LXF/VTimeLLM/data/stage2.json"
    download_path = '/data/lxf/datasets/internvid/'  # 原视频的路径
    # json_data = read_json_file(file_path)
    js = read_json_file(file_path)

    if js is not None:
        for item in tqdm(js):
            # 处理每个 JSON 对象，item 是字典
            id = item.get("id")
            data = item
            # 处理代码
            cou += 1
            video_id = id
            custom_filename = video_id + '.mp4'
            video = download_video(video_id, custom_filename,download_path)
        print("所有视频下载完成")
    else:
        print("Failed to read JSON data.")
    print(cou)

    # 创建并启动多个线程来下载视频
    #
