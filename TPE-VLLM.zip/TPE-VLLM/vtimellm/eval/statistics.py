import json
import re


def time(answer):
    matches = re.search(r"(\d{2}) (to|and) (\d{2})", answer)
    if not matches:
        return 0, 0
    from_number = float(matches.group(1)) / 100
    to_number = float(matches.group(3)) / 100
    return from_number, to_number


def write_log(log_path, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt):
    log = {
        "count": count,
        'video_id': video_id,
        "sentence_id": sentence_id,
        "iou": iou,
        "predicate_time": predicate_time,
        "gt_timestamp": timestamp,
        'answer': answer,
        "gt": gt
    }
    with open(log_path, 'a') as f:
        f.write(json.dumps(log) + '\n')


# 定义要读取的文件路径
file_path = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_16_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/7_16_fuxian_Stage2_for_train_activitynet_train_for_eval_log.txt'
# log_path_too_long =  '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_17_fuxian_Stage2_for_train_activitynet_train_for_eval_statistics/short.txt'
log_path_too_short = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/8_22_filtered_data/8_22_new_short.json'
# log_path_too_left =  '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_21_new_fuxian_Stage3_add_activitynet_train_data/Activitynet_too_left.txt'
# log_path_too_right = '/home/shige4090/lxf/LXF/VTimeLLM/vtimellm/eval/log/7_21_new_fuxian_Stage3_add_activitynet_train_data/Activitynet_too_right.txt'
# 打开文件并逐行读取内容
cou = 0
count = 0
counttt = 0
count_too_long, count_too_short, count_too_left, count_too_right = 0, 0, 0, 0

import json

# 读取 JSON 文件
with open(file_path, 'r', encoding='utf-8') as file:
    for line in file:
        data = json.loads(line)
        video_id = data['video_id']
        task = data['task']
        query_id = data['query_id']
        answer = data['answer']
        info = data['info']
        gt = info["gt"]
        gt_start_time = float(gt[0])
        gt_end_time = float(gt[1])
        iou = info["iou"]
        predicate_time = info["predicate_time"]
        predicate_start_time = float(predicate_time[0])
        predicate_end_time = float(predicate_time[1])
        timestamp = info["timestamp"]
        start_time, end_time = time(answer)
        sentence_id = info["sentence_id"]
        cou += 1
        # if predicate_time[0] >= timestamp[1]:
        #     count += 1
        #     write_log(log_path_too_right, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)

        if iou < 0.5:
            count += 1
            # if (predicate_end_time - predicate_start_time) >= ((timestamp[1] - timestamp[0]) * 2):
            #     count_too_long += 1
            #     # write_log(log_path_too_long, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
            if ((predicate_end_time - predicate_start_time) * 2) <= timestamp[1] - timestamp[0] :
                count_too_short += 1
                write_log(log_path_too_short, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
            # if gt_start_time - end_time > 0:
            #     count_too_left += 1
            #     # write_log(log_path_too_left, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
            # if start_time - gt_end_time > 0:
            #     count_too_right += 1
            #     # write_log(log_path_too_right, count, video_id, sentence_id, iou, predicate_time, timestamp, answer, gt)
print(count_too_short)
print(f"总共有 {cou} 条数据，其中iou小于0.5的有 {count} ，比例为 {round(count / cou, 2)};\n"
      f"长度偏长的有 {count_too_long} 个，比例为 {round(count_too_long / cou, 2)} ，在iou小于0.5中的比例为 {round(count_too_long / count, 2)} ;\n"
      f"长度偏短的有 {count_too_short} 个，比例为 {round(count_too_short / cou, 2)} ，在iou小于0.5中的比例为 {round(count_too_short / count, 2)} ;\n"
      f"长度偏左的有 {count_too_left} 个，比例为 {round(count_too_left / cou, 2)} ，在iou小于0.5中的比例为 {round(count_too_left / count, 2)} ;\n"
      f"长度偏右的有 {count_too_right} 个，比例为 {round(count_too_right / cou, 2)} ，在iou小于0.5中的比例为 {round(count_too_right / count, 2)} ;")
