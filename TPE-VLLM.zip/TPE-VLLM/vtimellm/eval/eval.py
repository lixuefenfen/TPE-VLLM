import os

root_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
import sys

sys.path.append(root_dir)

import clip
import re
import argparse
import torch
import json
import numpy as np
from tqdm import tqdm
from torchvision.transforms import Compose, Resize, CenterCrop, Normalize
from vtimellm.model.builder import load_pretrained_model
from vtimellm.utils import disable_torch_init
from vtimellm.mm_utils import VideoExtractor
from vtimellm.inference import inference

try:
    from torchvision.transforms import InterpolationMode

    BICUBIC = InterpolationMode.BICUBIC
except ImportError:
    from PIL import Image

    BICUBIC = Image.BICUBIC


# activitynet:
# fet_folder:/lxf/LXF/VTimeLLM/pre-extracted_feature/stage3_clip_feat
# video_folder:
# data_path:../eval/data/activitynet/val_2.json

# charades:
# feat_folder:
# video_folder:"/data/lxf/datasets/Charades_v1_480"
# data_path:../eval/data/charades/test.json

# stage3 = "/home/shige4090/lxf/LXF/VTimeLLM/checkpoints/fuxian-vtimellm-vicuna-v1-5-7b-stage3"

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--clip_path", type=str,
                        default="/home/shige4090/lxf/LXF/VTimeLLM/checkpoints/clip/ViT-L-14.pt")
    parser.add_argument("--pretrain_mm_mlp_adapter", type=str,
                        default="/home/shige4090/lxf/LXF/VTimeLLM/checkpoints/fuxian-vtimellm-vicuna-v1-5-7b-stage1/mm_projector.bin")
    parser.add_argument("--stage2", type=str,
                        default="/home/shige4090/lxf/LXF/VTimeLLM/checkpoints/fuxian-vtimellm-vicuna-v1-5-7b-stage2")
    parser.add_argument("--stage3", type=str,
                        default="/home/shige4090/lxf/LXF/VTimeLLM/checkpoints/8.31_marge_left+right+short+long_2500+four_task_full")
    parser.add_argument("--model_base", type=str, default="/home/shige4090/lxf/LXF/VTimeLLM/checkpoints/vicuna-7b-v1.5")
    parser.add_argument("--data_path", type=str, default="/home/shige4090/lxf/Benchmarking_QA/temporal_qa.json")
    parser.add_argument("--feat_folder", type=str, default=None)
    parser.add_argument("--video_folder", type=str, default="/data/lxf/datasets/Activitynet")
    # parser.add_argument("--task", type=str, default='captioning', choices=['all', 'grounding', 'captioning'])
    parser.add_argument("--log_path", type=str,
                        default='/home/shige4090/lxf/output.txt')
    parser.add_argument('--output_dir', default='/home/shige4090/lxf/output')
    parser.add_argument('--output_name', default='output')




    args = parser.parse_args()
    return args


def iou(outputs, gt):
    matches = re.search(r"(\d{2}) (to|and) (\d{2})", outputs)
    if not matches:
        return 0, 0, 0
    from_number = float(matches.group(1)) / 100
    to_number = float(matches.group(3)) / 100
    s, e = gt
    intersection = max(0, min(to_number, e) - max(from_number, s))
    union = max(to_number, e) - min(from_number, s)
    iou = intersection / union
    return round(iou, 2), from_number, to_number


def write_log(log_path, video_id, answer, info=None):
    log = {
        'video_id': video_id,
        'answer': answer
    }
    if info is not None:
        log['info'] = info
    with open(log_path, 'a') as f:
        f.write(json.dumps(log) + '\n')


# questions = {
#     'grounding': ['During which frames can we see {}?'],
#     'captioning': [
#         'Could you please describe the events in the video in detail? Be specific about the activities of individuals, their surroundings, and interactions with others. The output should be in JSON format, structured as follows: {"event": "xx", "timestamps": "from xx to xx"}.']
# }

if __name__ == "__main__":
    args = parse_args()
    disable_torch_init()
    tokenizer, model, context_len = load_pretrained_model(args, args.stage2, args.stage3)
    model = model.cuda()
    model.to(torch.float16)

    if args.video_folder is not None:
        clip_model, _ = clip.load(args.clip_path)
        clip_model.eval()
        clip_model = clip_model.cuda()

        video_loader = VideoExtractor(N=100)

        transform = Compose([
            Resize(224, interpolation=BICUBIC, antialias=True),
            CenterCrop(224),
            Normalize((0.48145466, 0.4578275, 0.40821073), (0.26862954, 0.26130258, 0.27577711)),
        ])

    with open(args.data_path) as file:
        gt_contents = json.load(file)
    output_list = []
    for sample in tqdm(gt_contents):
        features = None
        video_name = sample['video_name']
        sample_set = sample
        question = sample['Q']
        if features is None and args.video_folder is not None:
            for ext in ['mp4', 'mkv', 'webm']:
                video_path = os.path.join(args.video_folder, f"{video_name}.{ext}")
                if os.path.isfile(video_path):
                    _, images = video_loader.extract({'id': None, 'video': video_path})

                    images = transform(images / 255.0)
                    images = images.to(torch.float16)
                    with torch.no_grad():
                        features = clip_model.encode_image(images.to('cuda'))
        if features is None:
            print(f'Can not find video {video_name}')
            continue

        answer = inference(model, features, "<video>\n " + question, tokenizer)
        sample_set['pred'] = answer
        write_log(args.log_path, video_name, answer)
        output_list.append(sample_set)
        with open(os.path.join(args.output_dir, f"{args.output_name}.json"), 'w') as file:
            json.dump(output_list, file)





    # js = json.load(open(args.data_path))
    # for id, data in tqdm(js.items()):
    #     features = None

        # if args.feat_folder is not None:
        #     feat_path = os.path.join(args.feat_folder, f"{id}.npy")
        #     if os.path.isfile(feat_path):
        #         features = torch.from_numpy(np.load(feat_path)).cuda()
        #
        # if features is None and args.video_folder is not None:
        #     for ext in ['mp4', 'mkv', 'webm']:
        #         video_path = os.path.join(args.video_folder, f"{id}.{ext}")
        #         if os.path.isfile(video_path):
        #             _, images = video_loader.extract({'id': None, 'video': video_path})
        #
        #             images = transform(images / 255.0)
        #             images = images.to(torch.float16)
        #             with torch.no_grad():
        #                 features = clip_model.encode_image(images.to('cuda'))

        # if features is None:
        #     print(f'Can not find video {id}')
        #     continue
        #
        # if args.task in ['captioning', 'all']:
        #     for query_id, query in enumerate(questions['captioning']):
        #         answer = inference(model, features, "<video>\n " + query, tokenizer)
        #         write_log(args.log_path, id, 'captioning', query_id, answer)

        # if args.task in ['grounding', 'all']:
        #     for sentence_id, (timestamps, sentence) in enumerate(zip(data['timestamps'], data['sentences'])):
        #         sentence = sentence.strip().lower()
        #         if sentence.endswith("."):
        #             sentence = sentence[:-1]
        #
        #         for query_id, query in enumerate(questions['grounding']):
        #             answer = inference(model, features, "<video>\n" + query.format(sentence), tokenizer)
        #             gt1 = (timestamps[0] / data['duration'], timestamps[1] / data['duration'])
        #             u, from_number, to_number = iou(answer, gt1)
        #             gt_formatted = (round(gt1[0], 2), round(gt1[1], 2))
        #             # gt_formatted = tuple(f"{value:.2f}" for value in gt1)
        #             timestamp = (timestamps[0], timestamps[1])
        #             predicate = (round(from_number, 2), round(to_number, 2))
        #
        #             predicate_time = (round(from_number * data["duration"], 2), round(to_number * data["duration"], 2))
        #             # predicate_time_formatted = tuple(f"{value:.2f}" for value in predicate_time)
        #
        #             write_log(args.log_path, id, 'grounding', query_id, answer, info={"predicate": predicate,
        #                                                                               "gt": gt_formatted,
        #                                                                               "predicate_time": predicate_time,
        #                                                                               "timestamp": timestamp,
        #                                                                               "sentence_id": sentence_id,
        #                                                                               'iou': u})
